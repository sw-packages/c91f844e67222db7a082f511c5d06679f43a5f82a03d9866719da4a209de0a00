#include <config.h>
#define MBUITER_INLINE _GL_EXTERN_INLINE
#include "mbuiter.h"
